HARSHA SKIN CARE DIGITAL MENU

Open index.html in a browser to preview the page.

The final MAIN customer QR requires a public HTTPS URL for this page.
After publishing, the public page URL becomes the destination of the main QR.

The page includes:
- 16 service entries and prices
- Call and WhatsApp buttons for 8275566199
- Supplied PhonePe/UPI QR
- Supplied Instagram QR
- Dhule location button
